Beste nakijkers, prolog liefhebbers, lotgenoten,


Om iets werkbaars te krijgen, volg het volgende stappenplan:
1. cd naar deze map (Prolog)
2. start prolog
3. consult 'load_everything.pl'
4. type 'start.' voor het menu

Have fun...



Martijn van der Veen,
Robrecht Jurriaans,
Moos Hueting,
Eva Greiner
