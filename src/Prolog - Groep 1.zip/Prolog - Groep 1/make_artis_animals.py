#!/usr/bin/env python3
# niet uit te voeren op server: heeft geen python3


# settings
min_animals = 3
max_animals = 15

zoo_name = 'artis'

outputfile = 'db_dieren_artis.pl'
sourcefile = 'db_dieren_algemeen.pl'
animalnames = 'dierennamen.txt' # lange lijst met dierennamen


# SCRIPT
import random
import re

# making animal-species list
print()
print('+ Searching for animal species at Noah\'s Ark..')
fspecies = open(sourcefile, 'r')	# open prolog file
pattern1 = re.compile("^prop\([a-zA-Z]+,naam")
pattern2 = re.compile(",")
animal_species_list = ['foo']
for line in fspecies:
	line = line.replace(' ', '')	# removing whitespace
	if re.match(pattern1, line):	# if this line contains an animal..
		# .. throw away 'prop('
		animal_plus_shit = line[5:]
		# .. and everything from ','
		animalspecies = re.split(pattern2, animal_plus_shit)
		# put in list
		animal_species_list.append(animalspecies[0])

animal_species_list = animal_species_list[1:]	# removing 'foo'



# making animal-names list
print('+ Thinking of animal names..')
fnames = open(animalnames, 'r')
animal_name_list = ['foo']		# defining list
for line in fnames:
	animal = line[:-1]		# strip \n
	animal = animal.lower()		# lowercase
	animal_name_list.append(animal)	# add to list

animal_name_list = animal_name_list[1:]	# removing 'foo'



# generating animals
print('+ Making some animals.. (like God does all the time)')
# open file, write some info
foutput = open(outputfile, 'w')
foutput.write('% Artis project - specific '+zoo_name+' animals\n')
foutput.write('% Author: Martijn van der Veen\n')
foutput.write('% Automatically generated animal file for '+zoo_name+'.\n')
foutput.write('% Please do not edit but generate with make_artis_animals.py!\n')
foutput.write('\n\n\n')


for specie in animal_specie_list:	# do for all animal species

	foutput.write('/****** ' + specie + ' ******/\n')
	nr_of_animals = random.randint(min_animals, max_animals)

	for i in range(nr_of_animals):	# do for all to_generate animals

		# set the attributes of this specific animal

		# time to randomize!
		nr_animname = random.randint(0, len(animal_name_list)-1)
		nr_animgender = random.randint(1, 100)
		nr_animbirthplace = random.randint(1, 100)
		nr_animallergy = random.randint(1, 100)
		anim_birth = str(random.randint(1, 31))+'/'+str(random.randint(1, 12))
		anim_birth = anim_birth + '/' +str(random.randint(1989, 2008))
		anim_kids = str(random.randint(0, 8))
		# set attributes!
		anim_name = animal_name_list[nr_animname]	# set name
		animal_name_list[nr_animname:nr_animname+1] = []	# remove item
		if nr_animgender < 52:
			anim_gender = 'man'
		else:
			anim_gender = 'vrouw'
		if nr_animbirthplace < 21:
			anim_birpl = 'wild'
		else:
			anim_birpl = zoo_name
		if nr_animallergy < 5:
			anim_allergy = 'gras'
		elif nr_animallergy < 8:
			anim_allergy = 'vlees'
		elif nr_animallergy < 11:
			anim_allergy = 'borstel'
		elif nr_animallergy < 12:
			anim_allergy = 'verzorger'
		else:
			anim_allergy = 'geen'
		anim_x = 'volgt_nog_indien_later_nodig'


		foutput.write('isa('+anim_name+', '+specie+').\n')
		foutput.write(' prop('+anim_name+', specific, '+zoo_name+').\n')
		foutput.write(' prop('+anim_name+', geslacht, '+anim_gender+').\n')
		foutput.write(' prop('+anim_name+', geboorte, '+anim_birth+').\n')
		foutput.write(' prop('+anim_name+', geboorteplaats,'+anim_birpl+').\n')
		foutput.write(' prop('+anim_name+', aantal_jongen, '+anim_kids+').\n')
		if anim_allergy != 'geen':
		   foutput.write(' prop('+anim_name+', allergie, '+anim_allergy+').\n')
		foutput.write(' prop('+anim_name+', ziekte, '+anim_x+').\n')
		foutput.write(' prop('+anim_name+', mood, '+anim_x+').\n')
		foutput.write(' prop('+anim_name+', humeur, '+anim_x+').\n')


		foutput.write('\n')



	foutput.write('\n\n')


print()
print('+ Done! Going back to heaven now to get some sleep..')
print()

# eigenschappen:

#ziekte
#dieet
#psychische_status (indewar, rustig, dement)
#humeur (1-10: 10=blij, 5=neutraal, 1=depressief)
#       (te lang 1 = sterft oid)

